package org.example.machineCoding.CustomerIssue.managers;

public interface AgentSelector {
    String assignAgent(int issueType);
}
